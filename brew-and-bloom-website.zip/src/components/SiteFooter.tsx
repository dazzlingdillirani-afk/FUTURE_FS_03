import { Link } from "@tanstack/react-router";
import { Instagram, MapPin } from "lucide-react";

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-border bg-secondary/40">
      <div className="container-edge grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 font-serif text-2xl">
            <span className="inline-block h-2 w-2 rounded-full bg-accent" />
            Brew & Bloom
          </div>
          <p className="mt-4 max-w-sm text-sm text-muted-foreground">
            A neighborhood coffee bar serving single-origin espresso, slow-fermented pastries, and
            a really good morning.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-foreground">Visit</h4>
          <p className="mt-3 flex items-start gap-2 text-sm text-muted-foreground">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
            124 Linden Street<br />Brooklyn, NY 11201
          </p>
          <p className="mt-3 text-sm text-muted-foreground">Mon–Fri · 7am–6pm<br />Sat–Sun · 8am–5pm</p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-foreground">Explore</h4>
          <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
            <li><Link to="/menu" className="hover:text-foreground">Menu</Link></li>
            <li><Link to="/about" className="hover:text-foreground">Our Story</Link></li>
            <li><Link to="/contact" className="hover:text-foreground">Contact</Link></li>
          </ul>
          <div className="mt-5 flex gap-3">
            <a
              href="https://www.instagram.com/brewandbloomcoffee"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="rounded-full border border-border p-2 hover:bg-background"
            >
              <Instagram className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="container-edge flex flex-col justify-between gap-2 py-5 text-xs text-muted-foreground md:flex-row">
          <p>© {new Date().getFullYear()} Brew & Bloom Coffee. All rights reserved.</p>
          <p>Roasted with care in Brooklyn.</p>
        </div>
      </div>
    </footer>
  );
}
