import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Brew & Bloom Coffee" },
      { name: "description", content: "Espresso, pour-overs, seasonal lattes, and house-baked pastries at Brew & Bloom Coffee, Brooklyn." },
      { property: "og:title", content: "Menu — Brew & Bloom Coffee" },
      { property: "og:description", content: "Espresso, pour-overs, seasonal lattes, and house-baked pastries." },
    ],
  }),
  component: MenuPage,
});

const sections = [
  {
    title: "Espresso",
    items: [
      ["Espresso", "Double shot, house blend", "3.50"],
      ["Macchiato", "Espresso, dollop of foam", "4.00"],
      ["Cortado", "Equal parts espresso & warm milk", "4.50"],
      ["Cappuccino", "Espresso, steamed milk, foam", "5.00"],
      ["Latte", "Espresso & textured milk", "5.50"],
      ["Mocha", "Espresso, Valrhona cocoa, milk", "6.00"],
    ],
  },
  {
    title: "Slow Coffee",
    items: [
      ["V60 Pour-Over", "Rotating single-origin, brewed to order", "6.50"],
      ["Chemex (for two)", "Bright, clean, ceremonial", "12.00"],
      ["Cold Brew", "20-hour slow steep, on tap", "5.50"],
      ["Nitro Cold Brew", "Velvety, cascading", "6.00"],
    ],
  },
  {
    title: "Seasonal",
    items: [
      ["Honey Lavender Latte", "Local honey, dried lavender", "6.50"],
      ["Brown Butter Mocha", "Browned butter, dark chocolate", "6.75"],
      ["Cardamom Cortado", "House cardamom syrup", "5.50"],
    ],
  },
  {
    title: "From the Bakery",
    items: [
      ["Butter Croissant", "48-hour laminated, baked at 5am", "4.50"],
      ["Almond Danish", "Frangipane, toasted almonds", "5.50"],
      ["Pistachio & Rose Bun", "This week's special", "6.00"],
      ["Sourdough Toast", "Cultured butter, sea salt", "5.00"],
      ["Banana Bread", "Brown butter, walnut", "4.50"],
    ],
  },
];

function MenuPage() {
  return (
    <section className="container-edge py-20 md:py-28">
      <div className="mx-auto max-w-2xl text-center">
        <p className="eyebrow">The Menu</p>
        <h1 className="mt-4 text-5xl md:text-6xl">Small list,<br />done properly.</h1>
        <p className="mt-6 text-muted-foreground">
          We change the seasonal board every six weeks. Everything else has been on the menu
          since day one — and probably will be tomorrow, too.
        </p>
      </div>

      <div className="mt-20 grid gap-16 md:grid-cols-2 md:gap-24">
        {sections.map((s) => (
          <div key={s.title}>
            <div className="flex items-baseline justify-between border-b border-border pb-3">
              <h2 className="text-3xl">{s.title}</h2>
              <span className="font-serif text-sm italic text-muted-foreground">USD</span>
            </div>
            <ul className="mt-6 divide-y divide-border/60">
              {s.items.map(([name, desc, price]) => (
                <li key={name} className="grid grid-cols-[1fr_auto] gap-x-6 py-4">
                  <div>
                    <p className="font-medium">{name}</p>
                    <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
                  </div>
                  <p className="font-serif text-lg tabular-nums text-accent">{price}</p>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <p className="mx-auto mt-20 max-w-md text-center text-sm text-muted-foreground">
        Oat, almond, and house-made macadamia milks available at no extra charge.
      </p>
    </section>
  );
}
