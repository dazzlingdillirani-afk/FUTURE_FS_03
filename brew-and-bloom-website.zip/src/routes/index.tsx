import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Coffee, Leaf, Star } from "lucide-react";
import hero from "@/assets/hero-coffee.jpg";
import interior from "@/assets/cafe-interior.jpg";
import pastries from "@/assets/pastries.jpg";

export const Route = createFileRoute("/")({
  component: Home,
});

function Home() {
  return (
    <>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="container-edge grid items-center gap-10 py-16 md:grid-cols-12 md:py-24">
          <div className="md:col-span-6">
            <p className="eyebrow">Brooklyn · Est. 2018</p>
            <h1 className="mt-5 text-5xl leading-[1.05] md:text-7xl">
              A really good<br />
              <span className="italic text-accent">morning</span>, served daily.
            </h1>
            <p className="mt-6 max-w-md text-base text-muted-foreground md:text-lg">
              Single-origin espresso, slow-fermented pastries, and a corner table that always feels
              like yours.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/menu" className="btn-primary">
                See the Menu <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/visit" className="btn-ghost">Plan your visit</Link>
            </div>
            <div className="mt-10 flex items-center gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-1.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-accent text-accent" />
                ))}
              </div>
              <span>4.9 · 1,200+ neighborhood reviews</span>
            </div>
          </div>
          <div className="md:col-span-6">
            <div className="relative">
              <img
                src={hero}
                alt="Latte with rosetta art and a croissant on a wooden table"
                width={1600}
                height={1200}
                className="aspect-[4/5] w-full rounded-2xl object-cover shadow-[0_30px_60px_-30px_rgba(60,30,10,0.4)]"
              />
              <div className="absolute -bottom-6 -left-6 hidden rounded-xl border border-border bg-card p-4 shadow-lg md:block">
                <p className="eyebrow">Today's pour</p>
                <p className="mt-1 font-serif text-xl">Ethiopia · Yirgacheffe</p>
                <p className="text-xs text-muted-foreground">Bright, floral, stone fruit</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trio */}
      <section className="border-y border-border bg-secondary/40">
        <div className="container-edge grid gap-8 py-14 md:grid-cols-3">
          {[
            { icon: Coffee, title: "Espresso, dialed in daily", body: "Two house blends and a rotating single-origin, calibrated each morning." },
            { icon: Leaf, title: "Pastries from scratch", body: "48-hour cold-fermented dough baked in-house before the sun comes up." },
            { icon: Star, title: "A room that feels like home", body: "Free Wi-Fi, real ceramic cups, and tables built for lingering." },
          ].map((f) => (
            <div key={f.title} className="flex gap-4">
              <f.icon className="h-6 w-6 shrink-0 text-accent" />
              <div>
                <h3 className="text-xl">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Story preview */}
      <section className="container-edge grid gap-12 py-20 md:grid-cols-12 md:py-28">
        <div className="md:col-span-6">
          <img
            src={interior}
            alt="Warm café interior with brick walls and pendant lights"
            loading="lazy"
            width={1400}
            height={1000}
            className="aspect-[5/4] w-full rounded-2xl object-cover"
          />
        </div>
        <div className="md:col-span-6 md:pl-6">
          <p className="eyebrow">Our Story</p>
          <h2 className="mt-4 text-4xl md:text-5xl">
            Built by neighbors,<br />for neighbors.
          </h2>
          <p className="mt-6 text-muted-foreground">
            We opened in 2018 with one espresso machine and a borrowed oven. Seven years on,
            we're still the same little shop on Linden Street — just with better pastries and a
            longer queue on Saturdays.
          </p>
          <p className="mt-4 text-muted-foreground">
            Every bean is sourced from small farms we know by name, roasted weekly twenty
            blocks away.
          </p>
          <Link to="/about" className="btn-ghost mt-8">
            Read our story <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Pastry card */}
      <section className="container-edge pb-24">
        <div className="overflow-hidden rounded-3xl bg-primary text-primary-foreground">
          <div className="grid md:grid-cols-2">
            <div className="p-10 md:p-16">
              <p className="eyebrow" style={{ color: "var(--color-cream)" }}>This week</p>
              <h2 className="mt-4 font-serif text-4xl md:text-5xl">
                Pistachio & rose<br />morning bun.
              </h2>
              <p className="mt-5 max-w-md opacity-80">
                Buttery laminated dough, house-made pistachio cream, a whisper of rose. Available
                until Sunday, or until they're gone — usually by noon.
              </p>
              <Link to="/menu" className="mt-8 inline-flex items-center gap-2 rounded-full bg-cream px-6 py-3 text-sm font-medium text-espresso transition hover:bg-cream/90">
                See the full menu <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
            <img
              src={pastries}
              alt="Assortment of fresh pastries"
              loading="lazy"
              width={1200}
              height={900}
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </section>
    </>
  );
}
