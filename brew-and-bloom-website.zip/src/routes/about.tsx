import { createFileRoute } from "@tanstack/react-router";
import barista from "@/assets/barista-pour.jpg";
import interior from "@/assets/cafe-interior.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Our Story — Brew & Bloom Coffee" },
      { name: "description", content: "How a borrowed espresso machine on Linden Street became Brooklyn's favourite neighborhood coffee bar." },
      { property: "og:title", content: "Our Story — Brew & Bloom" },
      { property: "og:description", content: "From one espresso machine to a neighborhood ritual." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <section className="container-edge grid gap-12 py-20 md:grid-cols-12 md:py-28">
        <div className="md:col-span-5">
          <p className="eyebrow">Our Story</p>
          <h1 className="mt-4 text-5xl md:text-6xl">From one machine<br />to a morning ritual.</h1>
        </div>
        <div className="space-y-5 text-muted-foreground md:col-span-7 md:pt-10">
          <p>
            In the spring of 2018, Maya and Theo signed a lease on a 600-square-foot storefront
            with a leaky tap and a borrowed espresso machine. They named it Brew & Bloom — for the
            coffee, and for the second-hand flower stand they kept by the door.
          </p>
          <p>
            Today the flowers are still there. So is the original espresso machine, retired now,
            sitting on a shelf above the bar like a small monument. Everything else has grown:
            three roasters we work with by name, a baker named Sam who arrives at 4am, and a
            steady line that snakes out the door on Saturday mornings.
          </p>
          <p>
            What hasn't changed is the why. We make coffee for the people who live on this block,
            and the ones who come from a few blocks further. We learn your name. We learn your
            order. And we save you the corner table whenever we can.
          </p>
        </div>
      </section>

      <section className="bg-secondary/40 py-20 md:py-28">
        <div className="container-edge grid gap-12 md:grid-cols-2">
          <img
            src={barista}
            alt="Barista pouring milk for latte art"
            loading="lazy"
            width={1200}
            height={1400}
            className="aspect-[4/5] w-full rounded-2xl object-cover"
          />
          <div className="md:pl-8 md:pt-12">
            <p className="eyebrow">What we believe</p>
            <h2 className="mt-4 text-4xl md:text-5xl">Good coffee is a <span className="italic text-accent">conversation</span>.</h2>
            <ul className="mt-8 space-y-6">
              {[
                ["Direct trade, always.", "Every bean we serve is sourced from farms we've visited or have direct relationships with."],
                ["Roasted weekly.", "We pick up green beans on Monday. They're roasted Tuesday and on bar by Friday."],
                ["Pay our team well.", "A living wage, healthcare from day one, and tips that are actually tips."],
              ].map(([t, d]) => (
                <li key={t}>
                  <p className="text-lg">{t}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{d}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="container-edge py-20 md:py-28">
        <div className="grid gap-12 md:grid-cols-12">
          <div className="md:col-span-6">
            <img
              src={interior}
              alt="The café interior in golden light"
              loading="lazy"
              width={1400}
              height={1000}
              className="aspect-[5/4] w-full rounded-2xl object-cover"
            />
          </div>
          <div className="md:col-span-6 md:pl-6">
            <p className="eyebrow">The Numbers</p>
            <h2 className="mt-4 text-4xl">Seven years, <br />still counting.</h2>
            <div className="mt-10 grid grid-cols-2 gap-x-8 gap-y-10">
              {[
                ["38,000", "regulars and counting"],
                ["12", "small farms we source from"],
                ["4am", "when the dough starts"],
                ["1", "borrowed espresso machine, still on the shelf"],
              ].map(([n, l]) => (
                <div key={l}>
                  <p className="font-serif text-4xl text-accent">{n}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{l}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
