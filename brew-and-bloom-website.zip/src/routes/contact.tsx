import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Reservations — Brew & Bloom Coffee" },
      { name: "description", content: "Reserve a table, book your event, or just say hello. We typically respond within a few hours." },
      { property: "og:title", content: "Contact — Brew & Bloom" },
      { property: "og:description", content: "Reservations, private events, and hellos welcome." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);

  function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSent(true);
    toast.success("Message sent! We'll be in touch shortly.");
    (e.target as HTMLFormElement).reset();
  }

  return (
    <section className="container-edge py-20 md:py-28">
      <Toaster />
      <div className="grid gap-16 md:grid-cols-12">
        <div className="md:col-span-5">
          <p className="eyebrow">Say Hello</p>
          <h1 className="mt-4 text-5xl md:text-6xl">Let's<br />talk.</h1>
          <p className="mt-6 text-muted-foreground">
            Reservations, private events, wholesale, or just to tell us how that morning bun
            changed your day — we read every message.
          </p>
          <div className="mt-10 space-y-4 text-sm">
            <p><span className="text-muted-foreground">General · </span>hello@brewandbloom.cafe</p>
            <p><span className="text-muted-foreground">Events · </span>events@brewandbloom.cafe</p>
            <p><span className="text-muted-foreground">Wholesale · </span>beans@brewandbloom.cafe</p>
          </div>
        </div>

        <form onSubmit={onSubmit} className="md:col-span-7 space-y-5 rounded-2xl border border-border bg-card p-8 md:p-10">
          <div className="grid gap-5 md:grid-cols-2">
            <Field label="Name" name="name" required />
            <Field label="Email" name="email" type="email" required />
          </div>
          <Field label="Subject" name="subject" required />
          <div>
            <label className="text-sm font-medium">Message</label>
            <textarea
              required
              rows={6}
              name="message"
              className="mt-2 w-full rounded-lg border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20"
            />
          </div>
          <button type="submit" className="btn-primary w-full justify-center md:w-auto">
            {sent ? "Send another" : "Send Message"}
          </button>
        </form>
      </div>
    </section>
  );
}

function Field({ label, name, type = "text", required }: { label: string; name: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="text-sm font-medium">{label}</label>
      <input
        name={name}
        type={type}
        required={required}
        className="mt-2 w-full rounded-lg border border-input bg-background px-4 py-3 text-sm outline-none transition focus:border-accent focus:ring-2 focus:ring-accent/20"
      />
    </div>
  );
}
