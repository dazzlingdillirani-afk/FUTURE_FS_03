import { createFileRoute } from "@tanstack/react-router";
import { Clock, MapPin, Phone } from "lucide-react";

export const Route = createFileRoute("/visit")({
  head: () => ({
    meta: [
      { title: "Visit — Brew & Bloom Coffee" },
      { name: "description", content: "Find us at 124 Linden Street, Brooklyn. Open daily for espresso, pastries, and a corner table." },
      { property: "og:title", content: "Visit — Brew & Bloom" },
      { property: "og:description", content: "124 Linden Street, Brooklyn. Open daily." },
    ],
  }),
  component: Visit,
});

function Visit() {
  return (
    <section className="container-edge py-20 md:py-28">
      <div className="grid gap-12 md:grid-cols-12">
        <div className="md:col-span-5">
          <p className="eyebrow">Visit Us</p>
          <h1 className="mt-4 text-5xl md:text-6xl">Come find your<br />corner table.</h1>
          <p className="mt-6 text-muted-foreground">
            We're on the corner of Linden and Vine, right next to the bookshop. Look for the green
            awning and the flower stand by the door.
          </p>

          <div className="mt-10 space-y-6">
            <div className="flex items-start gap-4">
              <MapPin className="mt-1 h-5 w-5 text-accent" />
              <div>
                <p className="font-medium">124 Linden Street</p>
                <p className="text-sm text-muted-foreground">Brooklyn, NY 11201</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Clock className="mt-1 h-5 w-5 text-accent" />
              <div>
                <p className="font-medium">Open daily</p>
                <p className="text-sm text-muted-foreground">Mon–Fri · 7am – 6pm</p>
                <p className="text-sm text-muted-foreground">Sat–Sun · 8am – 5pm</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Phone className="mt-1 h-5 w-5 text-accent" />
              <div>
                <p className="font-medium">(718) 555-0142</p>
                <p className="text-sm text-muted-foreground">For reservations of 6 or more</p>
              </div>
            </div>
          </div>

          <div className="mt-10 flex gap-3">
            <a
              href="https://maps.google.com/?q=124+Linden+Street+Brooklyn"
              target="_blank"
              rel="noreferrer"
              className="btn-primary"
            >
              Get Directions
            </a>
            <a href="tel:+17185550142" className="btn-ghost">Call Us</a>
          </div>
        </div>

        <div className="md:col-span-7">
          <div className="overflow-hidden rounded-2xl border border-border">
            <iframe
              title="Map to Brew & Bloom Coffee"
              src="https://www.openstreetmap.org/export/embed.html?bbox=-73.998%2C40.690%2C-73.978%2C40.700&layer=mapnik&marker=40.695%2C-73.988"
              className="h-[520px] w-full"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
